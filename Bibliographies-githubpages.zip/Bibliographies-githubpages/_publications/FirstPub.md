---
title: "Alpha Publication"
collection: publications
permalink: _publications/FirstPub
excerpt: 'This paper is the first publication for the project'
date: 2021-05-15
venue: 'Publications'
---
This is the first publication for the project. You can download the project or the individual paper down below. 

[Download paper here](https://raw.githubusercontent.com/BibliographiesProject/Bibliographies/githubpages/files/MainRepository.pdf?token=AQVVQ2X2G6VMV4DKFWLZ3HTA2AEHQ)

[Download the project here](https://github.com/BibliographiesProject/Bibliographies/releases)
